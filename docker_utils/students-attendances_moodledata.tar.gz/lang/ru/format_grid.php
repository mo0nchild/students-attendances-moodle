<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'format_grid', language 'ru', version '4.5'.
 *
 * @package     format_grid
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['addsections'] = 'Добавить секцию';
$string['cannotconvertuploadedimagetodisplayedimage'] = 'Не удается сконвертировать загруженное изображение. Пожалуйста, сообщите подробности ошибки разработчику.';
$string['centre'] = 'По центру';
$string['crop'] = 'Подрезка';
$string['currentsection'] = 'Эта секция';
$string['default'] = 'По умолчанию - {$a}';
$string['defaultdisplayedimagefiletype'] = 'Тип отображаемого изображения';
$string['defaultdisplayedimagefiletype_desc'] = 'Устанавливает тип отображаемого изображения.';
$string['defaultgridjustification'] = 'Выравнивание сетки по умолчанию';
$string['defaultgridjustification_desc'] = 'Одно из: по левому краю, по центру, по правому краю, по ширине между секций, по ширине по краям, по ширине равномерно.';
$string['defaultimagecontainerratio'] = 'Соотношение сторон области изображения';
$string['defaultimagecontainerratio_desc'] = 'Соотношение сторон области изображения';
$string['defaultimagecontainerwidth'] = 'Ширина области изображения';
$string['defaultimagecontainerwidth_desc'] = 'Ширина области изображения';
$string['defaultimageresizemethod'] = 'Способ изменения размера изображения';
$string['defaultimageresizemethod_desc'] = 'Способ изменения размера изображения для размещения в области изображения';
$string['defaultpopup'] = 'Использовать всплывающее окно';
$string['defaultpopup_desc'] = 'Отобразить секцию во всплывающем окне вместо перехода на отдельную страницу секции.';
$string['defaultsectionbadgeingridbox'] = 'Значок секции в сетке';
$string['defaultsectionbadgeingridbox_desc'] = 'Показать значок секции в сетке.';
$string['defaultsectiontitleingridbox'] = 'Название секции в сетке';
$string['defaultsectiontitleingridbox_desc'] = 'Показать название секции в сетке.';
$string['defaultshowcompletion'] = 'Показывать завершение';
$string['defaultshowcompletion_desc'] = 'Показать завершение секции в сетке.';
$string['defaultsinglepagesummaryimage'] = 'Показать изображение секции в описании секции при отображении одной секции на странице';
$string['defaultsinglepagesummaryimage_desc'] = 'Если «Представление курса» установлено в значение «Показывать одну секцию на странице», и у секции есть описание, то изображение секции будет отображаться в соответствии с выбранной позицией.';
$string['deletesection'] = 'Удалить секцию';
$string['editsection'] = 'Редактировать секцию';
$string['editsectionname'] = 'Редактировать заголовок секции';
$string['end'] = 'По правому краю';
$string['gridjustification'] = 'Установить выравнивание сетки';
$string['gridjustification_help'] = 'Установить выравнивание сетки в одно из значений: по левому краю, по центру, по правому краю, по ширине между секций, по ширине по краям, по ширине равномерно';
$string['hidefromothers'] = 'Скрыть секцию';
$string['imagecontainerratio'] = 'Установите соотношение контейнера изображения относительно ширины';
$string['imagecontainerratio_help'] = 'Одно из: 3-2, 3-1, 3-3, 2-3, 1-3, 4-3 или 3-4';
$string['imagecontainerwidth'] = 'Установите ширину контейнера изображения';
$string['imagecontainerwidth_help'] = 'Одно из: 128, 192, 210, 256, 320, 384, 448, 512, 576, 640, 704 или 768';
$string['imageresizemethod'] = 'Установите метод изменения размера изображения';
$string['imageresizemethod_help'] = 'Установите значение: «Масштабирование» или «Подрезка» при изменении размера изображения для соответствия контейнеру';
$string['information'] = 'Информация';
$string['informationsettingsdesc'] = 'Информация о формате сетка';
$string['left'] = 'Слева';
$string['markedthissection'] = 'Эта секция помечена как текущая';
$string['markthissection'] = 'Пометить эту секцию как текущую';
$string['off'] = 'выкл';
$string['original'] = 'Исходный';
$string['page-course-view-grid'] = 'Главная страница курса в формате сетки';
$string['page-course-view-grid-x'] = 'Любая страница курса в формате сетки';
$string['pluginname'] = 'Сетка';
$string['popup'] = 'Использовать всплывающее окно';
$string['popup_help'] = 'Отображение секции во всплывающем окне вместо перехода на отдельную страницу секции';
$string['right'] = 'Справа';
$string['scale'] = 'Масштабирование';
$string['section0name'] = 'Основное';
$string['sectionbadgeingridbox'] = 'Значок секции в сетке';
$string['sectionbadgeingridbox_help'] = 'Отображать значок секции в сетке';
$string['sectionbreak'] = 'Разрыв секции';
$string['sectionbreak_help'] = 'Установить разрыв сетки на этой секции';
$string['sectionbreakheading'] = 'Заголовок разрыва секции';
$string['sectionbreakheading_help'] = 'Показывать этот заголовок в точке разрыва этой секции в сетке. Можно использовать HTML.';
$string['sectionimage'] = 'Изображение секции';
$string['sectionimage_help'] = 'Изображение секции';
$string['sectionimagealttext'] = 'Альтернативный текст для изображения';
$string['sectionimagealttext_help'] = 'Этот текст будет установлен как «alt» изображения, являясь атрибутом «alternative».';
$string['sectionname'] = 'Секция';
$string['sectiontitleingridbox'] = 'Название секции в сетке';
$string['sectiontitleingridbox_help'] = 'Показать заголовок секции в сетке';
$string['settings'] = 'Настройки';
$string['settingssettingsdesc'] = 'Настройки формата сетка';
$string['showcompletion'] = 'Показать завершение';
$string['showcompletion_help'] = 'Показать завершение секции в сетке';
$string['showfromothers'] = 'Показать секцию';
$string['singlepagesummaryimage'] = 'Показать изображение секции в описании секции при отображении одной секции на странице';
$string['singlepagesummaryimage_help'] = 'Если «Представление курса» установлено в значение «Показывать одну секцию на странице», и у секции есть описание, то изображение секции будет отображаться в соответствии с выбранной позицией.';
$string['spacearound'] = 'По ширине между секций';
$string['spacebetween'] = 'По ширине по краям';
$string['spaceevenly'] = 'По ширине равномерно';
$string['start'] = 'По левому краю';
$string['topic'] = 'Секция';
$string['topic0'] = 'Основное';
$string['webp'] = 'WebP';
