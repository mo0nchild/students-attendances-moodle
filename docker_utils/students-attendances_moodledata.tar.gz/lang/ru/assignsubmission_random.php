<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'assignsubmission_random', language 'ru', version '4.5'.
 *
 * @package     assignsubmission_random
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['assignment'] = 'Задание';
$string['assignments'] = 'Задания';
$string['enabled'] = 'Включено';
$string['enabled_help'] = 'Если включено, студенты получают варианты задания случайным образом из набора, подготовленного учителем. Заготовленные решения вариантов заданий могут быть доступны учителям.';
$string['getassignment'] = 'Вы можете {$a}';
$string['getassignmenttext'] = '<b>получить задание ЗДЕСЬ</b>';
$string['inputfiles'] = 'Файлы заданий';
$string['inputfiles_help'] = 'Файлы заданий можно добавлять только по одному или в виде zip-файла. В последнем случае распакуйте файл прямо здесь и удалите его после этого!<br />Если есть решения, то имена файлов заданий должны совпадать с соответствующими файлами решений.';
$string['outputfiles'] = 'Файлы решений';
$string['outputfiles_help'] = 'Файлы решений можно добавлять только по одному или в виде zip-файла. В последнем случае распакуйте файл прямо здесь и удалите его после этого!<br />Имена файлов решений должны совпадать с соответствующими файлами заданий.';
$string['pluginname'] = 'Случайное задание';
$string['responsefilesassignment'] = 'Файл задания:';
$string['responsefilessolution'] = 'Файл решения:';
$string['show_hide'] = 'Показать/скрыть файлы заданий';
$string['solution'] = 'Решение';
$string['solutions'] = 'Решения';
$string['typerandom'] = 'Случайное задание';
