<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'aiplacement_editor', language 'ru', version '4.5'.
 *
 * @package     aiplacement_editor
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['editor:generate_image'] = 'Создавать изображения с помощью ИИ в текстовом редакторе HTML';
$string['editor:generate_text'] = 'Создавать текст с помощью ИИ в текстовом редакторе HTML';
$string['generatecontent'] = 'Создать контент с помощью ИИ';
$string['generateimage'] = 'Создать изображение с помощью ИИ';
$string['generateimagesetting'] = 'Включить создание изображения';
$string['generateimagesetting_desc'] = 'Включить или отключить создание изображений из текстовой подсказки.';
$string['generatetext'] = 'Создать текст с помощью ИИ';
$string['generatetextsetting'] = 'Включить создание текста';
$string['generatetextsetting_desc'] = 'Включить или отключить создание текста из текстовой подсказки.';
$string['noeditor'] = 'Размещение «Текстовый редактор HTML» недоступно для этого контекста';
$string['pluginname'] = 'Размещение - текстовый редактор HTML';
$string['privacy:metadata'] = 'Плагин «Размещение - текстовый редактор HTML» не хранит никаких персональных данных.';
