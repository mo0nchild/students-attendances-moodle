<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Strings for component 'block_course_list', language 'ru', version '4.5'.
 *
 * @package     block_course_list
 * @category    string
 * @copyright   1999 Martin Dougiamas and contributors
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['adminview'] = 'Вид для администратора';
$string['allcourses'] = 'Администратору доступны все курсы';
$string['configadminview'] = 'Отображать ли все курсы в блоке «Курсы» или только те, в которых зарегистрирован администратор.';
$string['confighideallcourseslink'] = 'Скрыть ссылку «Все курсы» в нижней части блока. (Администраторы смогут видеть ссылку, несмотря на значение этого параметра.)';
$string['course_list:addinstance'] = 'Добавлять новый блок «Курсы»';
$string['course_list:myaddinstance'] = 'Добавлять новый блок «Курсы» на страницу «Личный кабинет»';
$string['hideallcourseslink'] = 'Скрыть ссылку «Все курсы»';
$string['owncourses'] = 'Администратору доступны только его собственные курсы';
$string['pluginname'] = 'Курсы';
$string['privacy:metadata'] = 'Блок «Курсы» только показывает данные о курсах и сам по себе не хранит никаких данных.';
